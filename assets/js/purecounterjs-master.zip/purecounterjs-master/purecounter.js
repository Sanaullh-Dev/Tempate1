import PureCounter from './js/purecounter';

const pure = new PureCounter;